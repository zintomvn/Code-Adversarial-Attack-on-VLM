exec(open('/mnt/data/h1_analysis/analyze.py').read().split('print(\'MAIN metrics\')')[0])
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
plt.rcParams.update({'font.size':10})
# Two scale rendering to show sensitive distributed map
fig,axs=plt.subplots(2,6,figsize=(17,6.7),layout='constrained')
for i,t in enumerate(checkpoints):
 a=axs[i//6,i%6];im=a.imshow(mprob[t],cmap='inferno',vmin=0,vmax=0.05,interpolation='nearest');a.set_title(f'Step {t}');a.set_xticks([]);a.set_yticks([])
axs[1,5].axis('off');fig.suptitle('Guide attention probability (common scale 0-0.05; brightest peak clipped)');fig.savefig(OUT+'/attention_map_comparable_clipped.png',dpi=185);plt.close(fig)
fig,axs=plt.subplots(2,6,figsize=(17,6.7),layout='constrained')
for i,t in enumerate(checkpoints):
 a=axs[i//6,i%6];a.imshow(mprob[t],cmap='inferno',vmin=0,vmax=np.percentile(mprob[t],99.5),interpolation='nearest');a.set_title(f'Step {t} (local scale)');a.set_xticks([]);a.set_yticks([])
axs[1,5].axis('off');fig.suptitle('Attention maps with independent per-checkpoint scaling - for location comparison ONLY');fig.savefig(OUT+'/attention_map_location_view.png',dpi=185);plt.close(fig)
fig,axs=plt.subplots(2,6,figsize=(18,7.7),layout='constrained');
for i,t in enumerate(checkpoints):
 a=axs[i//6,i%6];a.imshow(source);a.imshow(mprob[t],extent=(0,224,224,0),cmap='inferno',alpha=.62,vmin=0,vmax=.05,interpolation='nearest');a.set_title(f'Step {t}');a.axis('off')
 if t<300:
  b=sch[t][int(ck.loc[ck.step==t,'active_schedule_index'].iloc[0])]['box'];a.add_patch(Rectangle((224*b[0],224*b[1]),224*b[2],224*b[3],fill=False,edgecolor='#00FF00',linewidth=2))
axs[1,5].axis('off');fig.suptitle('Guided next-step region (green), probability map clipped at 0.05');fig.savefig(OUT+'/attention_region_overlays_clipped.png',dpi=185);plt.close(fig)
# Quantified cumulative effective region coverage (union of crops)
from PIL import Image
union=np.zeros((224,224),dtype=bool);per_stage=[]
for stage in range(1,11):
 ss=steps[steps.phase_group==stage]
 for r in ss.itertuples():
  x,y,w,h=r.crop;union[y:y+h,x:x+w]=True
 per_stage.append((stage,union.mean()*100))
print('cumulative union crop coverage by stage',per_stage)
# top attention mass in first phase
print('map0 top single patch /top10 ',mprob[0].max(),np.sort(mprob[0].ravel())[-10:].sum())
# compute budget saturation ratio continuous on saved PNG only - not exact float internal
for t in [30,150,300]:
 a=getim(f'checkpoints/step_{t:05d}.png');delta=np.abs(a.astype(np.float64)-source.astype(float))
 print('step',t,'mean(|delta|/16 clipped)',np.minimum(delta/16.,1).mean(),'pixels_changed',np.any(delta>0,axis=2).mean()*100)
# average negative signal vs log3
print('infoNCE log3 baseline',np.log(3),'negative loss final',steps.iloc[-30:].negative_loss.mean())
print('strict overlap totals',ph.pairwise_iou_over_0_3.sum() if 'pairwise_iou_over_0_3' in ph.columns else 'NA')
