import io,os,json,zipfile,hashlib
import numpy as np,pandas as pd
from PIL import Image
from scipy.stats import pearsonr,spearmanr,entropy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P='/mnt/data/adv_h1_n1_s300_v1.zip';OUT='/mnt/data/h1_analysis';z=zipfile.ZipFile(P);PREF='hybrid_dynamic/samples/00000/'
def jread(p): return json.loads(z.read(p))
def nread(p): return np.load(io.BytesIO(z.read(p)))
def getim(name): return np.array(Image.open(io.BytesIO(z.read(PREF+name))).convert('RGB'))
steps=pd.DataFrame([json.loads(x) for x in z.read(PREF+'steps.jsonl').decode().splitlines()]);
for key in ['foa_full','foa_crop']: steps[key+'_score']=steps[key].apply(lambda x:x['score']);
for key in ['mpc_similarity_source','mpc_similarity_target','foa_score','mpc_score','negative_loss','objective','step_seconds','elapsed_seconds','gradient_abs_max','linf_internal_255','phase_group','schedule_index','attention_step','precision_retries']:
 steps[key]=pd.to_numeric(steps[key]);
steps['negative_term']=-0.5*steps.negative_loss
steps['objective_reconstructed']=steps.foa_score+steps.mpc_score+steps.negative_term
steps['delta_objective']=steps.objective.diff();steps['source_target_gap']=steps.mpc_similarity_target-steps.mpc_similarity_source
steps['crop_area_pct']=steps['crop'].apply(lambda x: 100*x[2]*x[3]/224**2)
steps['hotspot_area_pct']=steps['hotspot'].apply(lambda x: 100*x[2]*x[3]/224**2)
steps['negative_ids_joined']=steps['negative_ids'].apply(lambda x:'-'.join(map(str,x)))
steps['gradient_zero']=steps.gradient_abs_max==0
steps.drop(columns=['foa_full','foa_crop','negative_scores']).to_csv(OUT+'/steps_metrics.csv',index=False)
checkpoints=list(range(0,301,30));mprob={t:nread(PREF+f'maps/step_{t:05d}.npz')['probability'] for t in checkpoints};mnorm={t:nread(PREF+f'maps/step_{t:05d}.npz')['minmax'] for t in checkpoints};ms={t:jread(PREF+f'maps/step_{t:05d}.json') for t in checkpoints};sch={t:jread(PREF+f'schedules/step_{t:05d}.json')['schedule'] for t in checkpoints}
source=getim('source.png');adv=getim('adversarial.png');target=getim('target.png');print('images',source.shape,adv.shape,target.shape)
for i in [0,30,60,90,120,150,180,210,240,270,300]:
 a=getim(f'checkpoints/step_{i:05d}.png')

def boxmask(box, shape=(14,14)):
 x,y,w,h=box
 X0=int(round(x*shape[1]));X1=int(round((x+w)*shape[1]));Y0=int(round(y*shape[0]));Y1=int(round((y+h)*shape[0]));M=np.zeros(shape,dtype=bool);M[Y0:Y1,X0:X1]=True;return M

def iou(boxa,boxb):
 a=boxa;b=boxb
 x0=max(a[0],b[0]);y0=max(a[1],b[1]);x1=min(a[0]+a[2],b[0]+b[2]);y1=min(a[1]+a[3],b[1]+b[3]);inter=max(0,x1-x0)*max(0,y1-y0);u=a[2]*a[3]+b[2]*b[3]-inter;return inter/u if u else np.nan
original_box=sch[0][0]['box'];origmask=boxmask(original_box)
rows=[]
for t in checkpoints:
 p=mprob[t];q=p.ravel().astype(float);p0=mprob[0].ravel().astype(float)
 topidx=np.argmax(p);top0=np.argmax(mprob[0]);topn=np.unravel_index(topidx,p.shape)
 pentropy=entropy(q,base=2);hhi=np.sum(q**2); eff=2**pentropy
 # top k attention mass and change
 r={'step':t,'pearson_to_initial':np.corrcoef(q,p0)[0,1], 'spearman_to_initial':spearmanr(q,p0).statistic,
    'jensen_shannon_to_initial':float(0.5*entropy(q,(q+p0)/2,base=2)+0.5*entropy(p0,(q+p0)/2,base=2)),
    'map_max':p.max(),'map_min':p.min(),'map_entropy_bits':pentropy,'map_effective_patches':eff,'top_1_patch_mass':p.max(),
    'top_5_patch_mass':np.sort(q)[-5:].sum(),'top_10_patch_mass':np.sort(q)[-10:].sum(),
    'raw_vision_attention_mass':ms[t]['mean_raw_vision_mass'],
    'original_hotspot_mass':p[origmask].sum(),'original_hotspot_mean':p[origmask].mean(),
    'top_patch_row':topn[0],'top_patch_col':topn[1],
    'initial_top_patch_mass':p.ravel()[top0],
    'current_top10_in_initial_top10':len(set(np.argsort(q)[-10:]) & set(np.argsort(p0)[-10:])),
    'current_top10_in_previous_top10':len(set(np.argsort(q)[-10:]) & set(np.argsort(mprob[max(0,t-30)].ravel())[-10:]))}
 if t>0:
  r.update({'pearson_to_prev':np.corrcoef(q,mprob[t-30].ravel())[0,1], 'l1_dist_prob_to_prev':np.abs(p-mprob[t-30]).sum()})
 if t<300:
  # actual used schedule index taken from the first step after checkpoint
  stp=t+1;sidx=int(steps.loc[steps.step==stp,'schedule_index'].iloc[0]);bx=sch[t][sidx]['box']; mb=boxmask(bx)
  r.update({'active_schedule_index':sidx,'active_box_x':bx[0],'active_box_y':bx[1],'active_box_w':bx[2],'active_box_h':bx[3], 'active_box_area_pct':mb.mean()*100,'active_box_attention_mass':p[mb].sum(), 'same_index_fixed_iou':iou(bx,sch[0][sidx]['box']), 'same_index_fixed_attention_mass':p[boxmask(sch[0][sidx]['box'])].sum(), 'same_index_fixed_box':str(sch[0][sidx]['box'])})
 rows.append(r)
ck=pd.DataFrame(rows);ck.to_csv(OUT+'/attention_checkpoints.csv',index=False)
phrows=[]
for phase in range(1,11):
 part=steps[steps.phase_group==phase];p0=phase-1
 bx=[x['box'] for x in sch[phase*30] if x['phase_group']==phase] # each stage scheduling? not used, instead active schedule from phase start 
 activeboxes=[r['hotspot'] for r in part.to_dict('records')]
 boxes_distinct=set(tuple(x) for x in activeboxes)
 active_sidx=sorted(part.schedule_index.unique().tolist())
 early_t=(phase-1)*30
 used_boxes=[sch[early_t][idx]['box'] for idx in active_sidx]
 pair_ious=[iou(a,b) for i,a in enumerate(used_boxes) for b in used_boxes[i+1:]]
 phrows.append({'phase':phase,'steps':len(part),'from_step':int(part.step.min()),'to_step':int(part.step.max()),'mean_objective':part.objective.mean(),'mean_foa':part.foa_score.mean(),'mean_mpc':part.mpc_score.mean(),'mean_negative_loss':part.negative_loss.mean(),'mean_source_sim':part.mpc_similarity_source.mean(),'mean_target_sim':part.mpc_similarity_target.mean(),'mean_gradient_abs_max':part.gradient_abs_max.mean(),'mean_crop_area_pct':part.crop_area_pct.mean(),'mean_hotspot_area_pct':part.hotspot_area_pct.mean(),'schedule_idx':str(active_sidx),'unique_hotspots':len(boxes_distinct),'pairwise_iou_mean':np.mean(pair_ious) if pair_ious else np.nan,'pairwise_iou_max':np.max(pair_ious) if pair_ious else np.nan,'pairwise_iou_over_0.3':sum(x>0.300001 for x in pair_ious),'pairwise_iou_count':len(pair_ious)})
ph=pd.DataFrame(phrows);ph.to_csv(OUT+'/phase_metrics.csv',index=False)
images=[]
for t in checkpoints:
 a=getim(f'checkpoints/step_{t:05d}.png');d=a.astype(float)-source.astype(float)
 images.append({'step':t,'linf_pixel':np.max(np.abs(d)),'mae_rgb_255':np.mean(np.abs(d)),'rmse_rgb_255':np.sqrt(np.mean(d*d)),'changed_RGB_pct':np.mean(d!=0)*100,'changed_any_pixel_pct':np.any(d!=0,axis=-1).mean()*100,'saturated_RGB_pct':np.mean(np.abs(d)>=16)*100,'psnr':10*np.log10(255**2/np.mean(d*d)) if np.mean(d*d) else np.inf})
imdf=pd.DataFrame(images);imdf.to_csv(OUT+'/image_distortion_checkpoints.csv',index=False)
# Metrics 
print('MAIN metrics')
for t in [1,10,30,31,60,90,150,180,210,240,270,300]:
 r=steps.loc[steps.step==t].iloc[0];print('step',t,'obj',round(r.objective,4),'foa',round(r.foa_score,4),'mpc',round(r.mpc_score,4),'neg',round(r.negative_loss,4),'source',round(r.mpc_similarity_source,4),'target',round(r.mpc_similarity_target,4),'ids',r.negative_ids_joined,'att',r.attention_step,'idx',r.schedule_index)
print('mean first30 last30')
print(steps.iloc[:30][['objective','foa_score','mpc_score','negative_loss','mpc_similarity_source','mpc_similarity_target','gradient_abs_max','step_seconds','crop_area_pct']].mean());print(steps.iloc[-30:][['objective','foa_score','mpc_score','negative_loss','mpc_similarity_source','mpc_similarity_target','gradient_abs_max','step_seconds','crop_area_pct']].mean())
print('overall component',steps[['objective','foa_score','mpc_score','negative_loss','mpc_similarity_source','mpc_similarity_target','gradient_abs_max','step_seconds','crop_area_pct']].describe().loc[['mean','min','max','std']])
print('checkpoints',ck.round(4).to_string(index=False))
print('phases',ph.round(4).to_string(index=False))
print('images',imdf.round(4).to_string(index=False))
print('gradient zero',sum(steps.gradient_zero), 'nonfinite',sum(~np.isfinite(steps[['objective','foa_score','mpc_score','negative_loss','gradient_abs_max']].to_numpy()).all(axis=1)),'precision retries',sum(steps.precision_retries), 'max objective error',np.max(np.abs(steps.objective-steps.objective_reconstructed)))
print('neg counts',steps.negative_ids_joined.value_counts().head(15).to_string())
print('neg distribution',pd.Series([i for ns in steps.negative_ids for i in ns]).value_counts().sort_index().to_string())
print('neg reselect count',sum(steps.negative_ids_joined!=steps.negative_ids_joined.shift())-1)
print('source_target_gap crossing:',int(steps[steps.source_target_gap>0].step.iloc[0]) if any(steps.source_target_gap>0) else None,'percent above:',(steps.source_target_gap>0).mean())
print('negative loss corr score',steps[['negative_loss','foa_score','mpc_score','objective']].corr().round(3))
print('step time > 10 count',sum(steps.step_seconds>10),'avg',steps.step_seconds.mean(),'median',steps.step_seconds.median(),'max',steps.step_seconds.max())
print('step time 30 multiples',steps[steps.step%30==0][['step','step_seconds']].to_string(index=False))
print('attention first box',sch[0][0]['box'],'mask patches',int(origmask.sum()))
# generate charts
plt.rcParams.update({'font.size':10})
fig,axs=plt.subplots(4,1,figsize=(12,12),sharex=True,layout='constrained');
axs[0].plot(steps.step,steps.objective,label='total objective',linewidth=1.3);axs[0].plot(steps.step,steps.objective.rolling(15,min_periods=1).mean(),label='rolling mean (15)',linewidth=2);axs[0].legend();axs[0].set_ylabel('Objective')
for key in ['foa_score','mpc_score','negative_term']:
 axs[1].plot(steps.step,steps[key],label=key,linewidth=1);axs[1].legend();axs[1].set_ylabel('Loss contribution')
axs[2].plot(steps.step,steps.mpc_similarity_source,label='source sim');axs[2].plot(steps.step,steps.mpc_similarity_target,label='target sim');axs[2].legend();axs[2].set_ylabel('MPC similarity')
axs[3].plot(steps.step,steps.gradient_abs_max,label='max |grad|');axs[3].set_yscale('log');axs[3].set_ylabel('Max gradient (log)');axs[3].set_xlabel('Attack update')
for ax in axs:
 for t in range(30,300,30):ax.axvline(t,alpha=.2,linewidth=.7)
 ax.grid(alpha=.2)
fig.savefig(OUT+'/optimization_diagnostics.png',dpi=150);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(10,8),sharex=True,layout='constrained');
for key in ['pearson_to_initial','original_hotspot_mass','raw_vision_attention_mass']:
 axs[0].plot(ck.step,ck[key],marker='o',label=key)
axs[0].legend();axs[0].set_ylabel('Attention metric');
axs[1].plot(ck.step,ck.map_entropy_bits,marker='o',label='Shannon entropy (bits)');axs[1].plot(ck.step,ck.map_effective_patches,marker='s',label='Effective patches');axs[1].legend();axs[1].set_xlabel('Checkpoint');axs[1].grid(alpha=.2)
fig.savefig(OUT+'/attention_dynamics_metrics.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(2,6,figsize=(18,7),layout='constrained');vmax=max(np.max(a) for a in mprob.values());
for i,t in enumerate(checkpoints):
 axarr=ax[i//6,i%6];axarr.imshow(mprob[t],vmin=0,vmax=vmax,cmap='magma',interpolation='nearest');axarr.set_title(f'step {t}');axarr.set_xticks([]);axarr.set_yticks([])
ax[1,5].axis('off');fig.suptitle('Qwen3-VL source-concept attention, fixed probability scale');fig.savefig(OUT+'/attention_map_timeline.png',dpi=170);plt.close(fig)
from matplotlib.patches import Rectangle
fig,axs=plt.subplots(2,6,figsize=(19,7),layout='constrained');
for i,t in enumerate(checkpoints):
 p=mprob[t];a=axs[i//6,i%6];a.imshow(source);a.imshow(p,extent=(0,224,224,0),cmap='inferno',alpha=.56,vmin=0,vmax=vmax,interpolation='nearest');a.set_title(f'Step {t}');a.axis('off')
 if t<300:
  b=sch[t][int(ck.loc[ck.step==t,'active_schedule_index'].iloc[0])]['box'];a.add_patch(Rectangle((224*b[0],224*b[1]),224*b[2],224*b[3],fill=False,edgecolor='lime',linewidth=2))
axs[1,5].axis('off');fig.suptitle('Attention on source image, active next-step hotspot (green outline)');fig.savefig(OUT+'/attention_overlaid_regions.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,4,figsize=(16,4),layout='constrained');
for a,arr,label in zip(axs,[source,adv,target,np.minimum(255,np.abs(adv.astype(float)-source.astype(float))*8).astype('uint8')],['Source image','Adversarial after 300','Target image','|perturbation| magnified ×8']):a.imshow(arr);a.set_title(label);a.axis('off')
fig.savefig(OUT+'/source_adversarial_target.png',dpi=180);plt.close(fig)
# time/budget
fig,axs=plt.subplots(2,1,figsize=(10,8),layout='constrained');axs[0].plot(steps.step,steps.step_seconds);axs[0].set_ylabel('Seconds per iteration');axs[0].set_yscale('log');axs[1].plot(imdf.step,imdf.mae_rgb_255,marker='o',label='mean |Δpixel| /255');axs[1].plot(imdf.step,imdf.saturated_RGB_pct,marker='o',label='RGB channels at ±16/255 (%)');axs[1].set_ylabel('Pixel distortion');axs[1].legend();axs[1].set_xlabel('Checkpoint');fig.savefig(OUT+'/runtime_distortion.png',dpi=150);plt.close(fig)
# report JSON
summ={'sample':'00000','num_iterations':len(steps),'num_maps':len(mprob),'start_end':{},'runtime_s':jread(PREF+'attack_stats.json')['elapsed_seconds']}
for k in ['objective','foa_score','mpc_score','negative_loss','mpc_similarity_source','mpc_similarity_target','gradient_abs_max','step_seconds']:
 summ['start_end'][k]={'step1':float(steps.iloc[0][k]),'step300':float(steps.iloc[-1][k]),'mean_first30':float(steps.iloc[:30][k].mean()),'mean_last30':float(steps.iloc[-30:][k].mean())}
with open(OUT+'/summary_metrics.json','w') as f:json.dump(summ,f,indent=2)
