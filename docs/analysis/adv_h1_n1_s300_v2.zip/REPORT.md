# Research audit: `adv_h1_n1_s300_v1.zip` — H1 Hybrid Dynamic, n=1, steps=300

**Scope:** single sample `00000`, one experimental variant `hybrid_dynamic`. There are **no victim-LVLM outputs, attack-success labels, or paired baseline runs** in the archive. Therefore no ASR, significance test across images, or transferability improvement can be inferred. All numeric results below were recomputed locally from the ZIP, not estimated from figures.

## Dataset and reproducibility

- `summary.json`: status `complete`, `completed=1`, `total=1`.
- `run_config.json`: `STEPS=300`, `EPSILON_255=16`, `ALPHA_255=1`, `NUM_PHASES=10`, `HOTSPOT_TOP_K=3`, `HOTSPOT_IOU=0.3`, `REFRESH_EVERY=30`, `K_NEG=2`, `NEGATIVE_LOSS='infonce'`, `LOSS_WEIGHTS={'foa':1.0,'mpc':1.0,'negative':0.5}`, `ATTENTION_LAYER=29`, Qwen3-VL-8B, surrogate CLIP B/16, B/32, ViT-G/14 LAION. `HYBRID_MOMENTUM=0`, `HYBRID_AMP=false`.
- `hybrid_dynamic/samples/00000/steps.jsonl`: exactly 300 optimization records; 0 non-finite objective/gradients, 0 precision retries, objective arithmetic agrees with `FOA+MPC-0.5*negative_loss` to `2.37e-7`.
- `hybrid_dynamic/samples/00000/maps/step_XXXXX.npz`: 11 normalized 14x14 probability maps for checkpoint steps 0, 30, ..., 300. Metadata (`maps/step_XXXXX.json`) confirms **same teacher-forced source caption** and nine fixed selected content tokens at all checkpoints. `step_00300` map occurs after all 300 updates and is diagnostic only.
- `hybrid_dynamic/samples/00000/schedules/step_XXXXX.json`: 28 indexed hotspot entries per schedule (27 in stages 1–9 and one whole-image entry in stage 10).
- `text_records.json`: source caption identifies a panda; targeted caption describes a black-and-white dog brushed with a red toothbrush. Nine accepted negative captions alter the actor or brushing tool, **not the central dog noun phrase**.

## A. Optimization results

Data source: `hybrid_dynamic/samples/00000/steps.jsonl`; reproducible rows in `steps_metrics.csv` and stage averages in `phase_metrics.csv`.

| Metric | Steps 1–30 mean | Steps 271–300 mean | Delta |
|---|---:|---:|---:|
| Total objective | 1.4052 | 2.4707 | +1.0655 |
| FOA score | 1.9862 | 2.9892 | +1.0030 |
| MPC score | -0.0620 | -0.0052 | +0.0567 |
| Negative loss | 1.0380 | 1.0266 | -0.0114 |
| MPC source similarity | 0.6076 | 0.5544 | -0.0533 |
| MPC target similarity | 0.5907 | 0.8037 | +0.2130 |
| Max abs. input gradient | 0.002339 | 0.000356 | -84.8% |
| Mean crop area | 5.52% | 66.82% | +61.30 percentage points |

Important comparability caveat: the optimization objective is recomputed using newly sampled and progressively larger crops. Comparing objective values across steps **does not provide a fixed-input evaluation metric**. Pearson correlation between FOA and total objective over 300 logged updates is ~0.999, indicating FOA score largely determines time variation of the combined numeric objective; component magnitudes also depend on their chosen normalization.

Phase averages: phases 1–10 total-objective means = 1.4052, 1.7353, 1.7985, 2.0072, 2.1655, 2.2983, 2.3645, 2.4172, 2.4426, 2.4707. **135/299** consecutive objective transitions are negative (per-crop stochasticity). Net within-phase objective change was negative in phases 8 (−0.0606), 9 (−0.0125), 10 (−0.0179). Convergence/plateau is a hypothesis, not proved without a fixed-input validation objective.

## B. Dynamic attention results

The `probability` tensor in each `maps/step_XXXXX.npz` is normalized to sum 1 across 196 visual patches. Pearson/Spearman and mass are computed from these normalized maps (not from `minmax` tensors). Detailed results are in `attention_checkpoints.csv`.

| Step | Pearson vs. step 0 | Max single-patch attention | Entropy (bits) | Effective patches (2^entropy) | Mean raw attention-to-vision mass | Original hotspot attention mass |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1.0000 | 0.4331 | 4.9013 | 29.9 | 0.1659 | 0.0341 |
| 30 | 0.0646 | 0.0364 | 6.9243 | 121.5 | 0.0946 | 0.0645 |
| 60 | 0.0271 | 0.0502 | 6.8451 | 115.0 | 0.0950 | 0.0435 |
| 90 | 0.0430 | 0.0499 | 6.8090 | 112.1 | 0.0998 | 0.0840 |
| 150 | 0.0119 | 0.0412 | 6.8569 | 115.9 | 0.1112 | 0.1015 |
| 210 | 0.0070 | 0.0476 | 6.9391 | 122.7 | 0.1021 | 0.0895 |
| 270 | -0.0368 | 0.0395 | 6.9771 | 126.0 | 0.1003 | 0.0743 |
| 300 | -0.0131 | 0.0365 | 7.0303 | 130.7 | 0.0957 | 0.0842 |

**Outlier/interpretation:** step 0 concentrates 43.31% of all normalized visual-patch probability in one patch (row=3,col=13, zero-indexed). After 30 steps that single peak collapses; Pearson ≈ 0.065, although Spearman rank correlation is still 0.768, showing much of the lower-ranked ordering remains. Thus the appearance of a huge redistribution is **highly sensitive to the initial extreme patch**. The 30-step raw attention-to-vision mass falls 16.59% → 9.46%; this is a separate metric from the normalized spatial probability distribution.

The first scheduled hotspot covers 18/196 patches = **9.18%** of the grid but contains only **3.41%** of spatial probability, and none of the three stage-1 hotspots contains the step-0 argmax patch. The initial hotspot contains **8.42%** of attention at step 300: its spatial attention share increased, not decreased. This does not rule out SAGA's mechanism, as the dominant initial attention spike lies **outside** the attacked first region; it does require checking the selection heuristic. Whether this is an intentional spatial-consistency filter, a Qwen attention artifact, or a code issue **cannot be diagnosed from saved results alone** (the ZIP lacks executable attack source code).

**Selection contrast:** At step 60, the actually chosen dynamic hotspot covers 28.57% of patches but has only 21.67% attention mass; the same-index *initial fixed* hotspot under the **current** map has 27.41% mass. This is a descriptive counterexample to assuming dynamic always selects the highest attention mass. It does **not** show the fixed baseline is a better attack, since there was no fixed run.

## C. Scheduled hotspot overlap and loss of adaptivity

Measured from the actual region boxes in `steps.jsonl`; `phase_metrics.csv` contains exact per-phase IoU.

| Phase | Mean active hotspot area | Mean pairwise hotspot IoU | Hotspot pairs IoU > 0.3 |
|---:|---:|---:|---:|
| 1 | 9.18% | 0.162 | 0/3 |
| 2 | 20.41% | 0.160 | 0/3 |
| 3 | 29.93% | 0.196 | 0/3 |
| 4 | 40.31% | 0.268 | 0/3 |
| 5 | 50.68% | 0.485 | 2/3 |
| 6 | 61.56% | 0.838 | 3/3 |
| 7 | 72.96% | 0.805 | 3/3 |
| 8 | 79.59% | 0.854 | 3/3 |
| 9 | 92.86% | 0.864 | 3/3 |
| 10 | 100% | — | only one full-image box |

**14/27** across-hotspot comparisons exceed configured IoU=0.3. The constraint value is configured, but the saved schedule does not enforce it strictly at higher phase areas. Without code, the exact reason (fallback rule vs implementation error) is unresolved. In phase 10 the hotspot is guaranteed the whole image regardless of attention; the dynamic map at step 270 cannot affect that hotspot; the map at step 300 is purely post-hoc.

## D. Image perturbation budget

Derived from `source.png` and 11 saved checkpoint PNGs (8-bit, 224 × 224 RGB). Data: `image_distortion_checkpoints.csv`.

| Step | Mean RGB abs. diff /255 | % image pixels with any RGB change | % RGB channels at |Δ|=16 | PSNR dB |
|---:|---:|---:|---:|---:|
| 30 | 0.4552 | 18.93% | 0.004% | 45.46 |
| 90 | 2.1851 | 72.84% | 0.144% | 37.36 |
| 150 | 3.7978 | 93.33% | 0.968% | 33.73 |
| 210 | 4.7880 | 96.49% | 1.986% | 32.03 |
| 270 | 5.7042 | 98.46% | 2.815% | 30.89 |
| 300 | 6.1433 | 99.51% | 3.213% | 30.44 |

At the final checkpoint, max pixel-channel change is **16/255**. An `L∞`-bounded attack can be widespread but modest in each channel; it is not necessarily localized in the final image. Using the saved PNG only, the normalized mean budget saturation ratio `mean(min(|delta| / 16, 1))` is **0.384** at step 300. This is not a pixel-saturation rate; only **3.21%** RGB channels equal the absolute maximum.

Cumulative spatial union of actual attack crops reaches **89.18%** by phase 4, **93.99%** by phase 5, and **99.76%** by phase 10. This is a *historical coverage* statistic, not a count of channels with nonzero final perturbation.

## E. Negative-sample diagnostics

Source: `text_records.json` and every record's `negative_ids`, `negative_loss`, `negative_scores` in `steps.jsonl`. Nine accepted negatives are three replacements of the red toothbrush with a different tool, and six replacements of “a person” with a different actor. None edits “dog” into another category, despite “dog” being the primary adversarial class target. Mining changes ordered negative ID pair **12 times**. The most frequently selected IDs are #7 (monkey) in **230/300 updates**, #2 (yellow nail clipper) in **190/300 updates**, and #8 (giraffe) in **100/300**; frequencies overlap because two negatives are selected per update. The ordered pair `(7,8)` is used for the first **100** steps.

Negative loss first-stage mean **1.0380**, final-stage **1.0266**. For the conditional conventional 1-positive-versus-2-negative InfoNCE definition, `ln(3)≈1.0986` is the all-equal-score reference; these values are relatively close, and little separation is apparent in the trace. The exact semantic meaning depends on the loss implementation (not bundled). Recommendation: log target-vs-hard-negative margins and per-negative similarities, and expand controlled negative categories to include changes in object species, color, action, actor and tool independently.

## F. Runtime and failure checks

`attack_stats.json` reports **1199.45 seconds = 19.99 minutes**, CUDA peak allocations about **6.36 GiB on cuda:0** and **6.01 GiB on cuda:1** (6832314368 and 6451344896 bytes). Iteration 1 took 25.38 seconds; iterations 31, 61, ..., 271 took ~11.3–11.5s against a typical 3.6–3.7s, consistent with attention refresh overhead. Captions were cached in `events.jsonl`. No invalid floating point / retries were detected. Extrapolations to n=100 or 1000 must be treated only as single-sample serial estimates, not measured runtime.

## G. Conclusion and research hypotheses

1. **Strong surrogate alignment trend:** target similarity rises substantially while source similarity falls. **Not ASR evidence.**
2. **Attention dispersion is real but dominated early by one extreme visual patch:** per-map entropy is necessary to interpret correlation. An isolated attention spike may be spatial-position artifact or a legitimate feature; test with source flips, alternate layers, smoothing and occlusion.
3. **Initial selection appears inconsistent with a naive highest-mass criterion:** one initial hotspot has 3.41% attention on 9.18% area, and the 43.31% peak is absent from all three first-stage regions. Audit hotspot selection scoring and robustness to isolated peaks.
4. **Late-stage region schedule is redundant:** >50% of eligible hotspot pairs violate IoU=0.3 and the final stage is wholly non-adaptive. Cap hotspot area at 30–50%, use strict IoU or allow fewer than 3 regions, and stop or change refresh cadence once the active mask reaches the entire image.
5. **Objective improvements decelerate as crops enlarge, gradient magnitude shrinks and perturbation area spreads:** evaluate using a fixed-input surrogate objective and LPIPS/SSIM to determine a Pareto-optimal stopping point.
6. **Negative sampling is concept-imbalanced:** the generated accepted negatives do not contrast the main dog class. Run targeted semantic-factor hard negative ablations and measure target-vs-negative margin.

### Priority experiment protocol

Keep exact source/target pairs, seeds, 300 gradient updates, perturbation budget, surrogate ensemble and caption generation fixed. Compare FOA; FOA+MPC; +negative; +fixed attention; +dynamic attention; dynamic+EMA; dynamic+area cap/strict IoU; dynamic+region sensitivity probe. Measure ASR and average judged similarity from **actual victim-generated captions**, confidence intervals over 100–1000 paired images, fixed evaluation CLIP target similarity, perceptual distortion, query/compute time, attention-change entropy, maximum-peak location stability, actual IoU and perturbation saturation. Separate auxiliary probe compute from gradient update count and report both budgets.

### Figures

- `source_adversarial_target.png`: visual appearance and amplified perturbation.
- `attention_map_timeline.png`: consistent scale including extreme outlier, all checkpoints.
- `attention_map_comparable_clipped.png`: same clipped 0–0.05 scale to examine later maps.
- `attention_map_location_view.png`: per-frame scaling, usable **only for location comparison**.
- `attention_region_overlays_clipped.png`: attention with next active selected hotspot on source image.
- `optimization_diagnostics.png`: 300-step loss, source/target alignment, gradient curves.
- `attention_dynamics_metrics.png`: correlation, hotspot mass, entropy/effective patches.
- `runtime_distortion.png`: runtime spikes, mean pixel changes and bound saturation.

### Limitations

The archive does **not** include actual victim model responses, ASR, the attack source code, nor matched runs for the configured baseline variants. Do not claim the method is better than SAGA, FOA, MPC or any black-box target from this one-sample run.
