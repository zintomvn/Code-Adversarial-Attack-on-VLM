import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd,numpy as np,zipfile,io
from PIL import Image
p='/mnt/data/attack_analysis/';z=zipfile.ZipFile('/mnt/data/adv_foa-saga-concept_n100_s300_v1.zip')
df=pd.read_csv(p+'checkpoints.csv');s=pd.read_csv(p+'samples.csv');c=pd.read_csv(p+'schedule_comparison.csv'); g=pd.read_csv(p+'stage_metrics.csv')
plt.rcParams.update({'font.size':11,'axes.grid':True,'grid.alpha':.15,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})

# figure 1 attention trend
fig,ax=plt.subplots(figsize=(9.0,4.4),dpi=170)
st=df.groupby('step').initial_hotspot_mass.agg(['mean','std']);lo=st['mean']-st['std'];hi=st['mean']+st['std']
ax.plot(st.index,st['mean'],marker='o',label='Mean initial-hotspot attention mass')
ax.fill_between(st.index,lo,hi,alpha=.15,label='±1 SD across images')
ax.axhline(18/196,linestyle='--',alpha=.55,label='Uniform attention baseline (9.18% area)')
ax.set(xlabel='Attack iteration',ylabel='Normalized attention mass',title='Attention at the initially selected hotspot (n = 100)',ylim=(0,.43))
ax.legend(loc='upper right',fontsize=9);fig.tight_layout();fig.savefig(p+'attention_hotspot_mass.png',bbox_inches='tight');plt.close(fig)

# figure 2 schedule & map drift
fig,ax=plt.subplots(figsize=(9,4.4),dpi=170)
means=df.groupby('step')[['attention_corr_init','attention_corr_prev']].mean()
ax.plot(means.index,means['attention_corr_init'],marker='o',label='Map correlation vs iteration 0')
ax.plot(means.index,means['attention_corr_prev'],marker='s',label='Map correlation vs previous checkpoint')
ax.set(xlabel='Attack iteration',ylabel='Pearson correlation (14×14 patch probabilities)',title='Attention maps evolve substantially (n = 100)',ylim=(-.05,1.05))
ax.legend(fontsize=10);fig.tight_layout();fig.savefig(p+'attention_correlations.png',bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.4),dpi=170)
st=c.groupby('step')[['iou_vs_fixed','iou_vs_previous_schedule']].mean()
ax.plot(st.index,st.iou_vs_fixed,marker='o',label='Dynamic hotspot vs fixed schedule')
ax.plot(st.index,st.iou_vs_previous_schedule,marker='s',label='Dynamic hotspot vs previous schedule')
ax.set(xlabel='Recompute iteration',ylabel='IoU of next scheduled region',title='Dynamic region selection becomes indistinguishable late',ylim=(0,1.08))
ax.legend(fontsize=10);fig.tight_layout();fig.savefig(p+'schedule_iou.png',bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.4),dpi=170)
st=g.groupby('step_end')[['mean_objective','crop_mean_area']].mean()
ax.plot(st.index,st.mean_objective,marker='o',label='FOA objective')
ax.set(xlabel='Attack iteration',ylabel='Average crop-specific FOA objective',title='Objective rises while crop size changes (n = 100)')
ax2=ax.twinx();ax2.plot(st.index,st.crop_mean_area,marker='s',linestyle='--',label='Mean crop area / full image')
ax2.set(ylabel='Relative crop area',ylim=(0,.8))
lines=ax.get_lines()+ax2.get_lines();ax.legend(lines,[x.get_label() for x in lines],fontsize=10,loc='upper left')
fig.tight_layout();fig.savefig(p+'foa_objective_crops.png',bbox_inches='tight');plt.close(fig)

# case attention visual
ids=[0,23,80];steps=[0,30,90,180,240,300]
fig,axes=plt.subplots(len(ids),len(steps)+1,figsize=(18,8.4),dpi=145)
for row,j in enumerate(ids):
 sid=f'{j:05d}';im=np.array(Image.open(io.BytesIO(z.read(f'images/{sid}_source.png'))).convert('RGB'))
 maps=[]
 for t in steps:
  map=np.load(io.BytesIO(z.read(f'samples/{sid}/attention/step_{t:05d}/guide.npz')))['probability']; maps.append(map)
 vmax=max(float(x.max()) for x in maps)
 axes[row,0].imshow(im);axes[row,0].set_title(f'Sample {sid}\nSource image',fontsize=10)
 for col,(t,mp) in enumerate(zip(steps,maps),1):
  a=axes[row,col];a.imshow(im);a.imshow(mp,extent=(0,im.shape[1],im.shape[0],0),vmin=0,vmax=vmax,alpha=.7,cmap='inferno',interpolation='nearest')
  a.set_title(f'Step {t}\npeak={mp.max():.3f}',fontsize=10)
 for a in axes[row]: a.axis('off')
fig.suptitle('Guide attention over time — fixed source caption (shared color scale within each sample)',fontsize=14)
fig.subplots_adjust(top=.88,bottom=.03,wspace=.08,hspace=.24);fig.savefig(p+'attention_case_montage.png',bbox_inches='tight');plt.close(fig)

# source / adv / perturb sample0 and 80
fig,axes=plt.subplots(2,4,figsize=(12.2,6.1),dpi=150)
for i,j in enumerate([0,80]):
 sid=f'{j:05d}';src=np.array(Image.open(io.BytesIO(z.read(f'images/{sid}_source.png'))).convert('RGB'))
 tgt=np.array(Image.open(io.BytesIO(z.read(f'images/{sid}_target.png'))).convert('RGB'))
 adv=np.array(Image.open(io.BytesIO(z.read(f'images/{sid}_adversarial.png'))).convert('RGB'))
 diff=np.abs(adv.astype('float32')-src.astype('float32'))
 for k,img in enumerate([src,tgt,adv,np.clip(diff/16.0,0,1)]):
  axes[i,k].imshow(img);axes[i,k].axis('off');
  if i==0:axes[i,k].set_title(['Source','Target image','Adversarial','|Difference| scaled by 16'][k],fontsize=11)
 axes[i,0].set_ylabel(f'Sample {sid}')
fig.suptitle('Output images and perturbation footprint (visualization, not victim model outcomes)',fontsize=12)
fig.tight_layout();fig.savefig(p+'image_perturbations.png',bbox_inches='tight');plt.close(fig)
print('generated all plots')
