# Research analysis — FOA + Dynamic SAGA Concept Attention (100 images × 300 steps)

## Phạm vi và nguồn

Báo cáo tính lại từ `adv_foa-saga-concept_n100_s300_v1.zip`, không chạy lại inference. Nguồn trực tiếp:

- `run_config.json`, `summary.json`, `status.json`, `manifest.jsonl` (thiết lập và trạng thái)
- `samples/{id}/trace.csv` (30.000 bản ghi gradient update)
- `samples/{id}/attention/step_{step}/guide.npz`, `guide.json` (1.100 guide attention maps + metadata)
- `samples/{id}/attention/step_{0,150,300}/{source,target}.npz` (diagnostics concept)
- `samples/{id}/attention/checkpoint_metrics.jsonl` và `samples/{id}/schedules/step_*.json` (attention mass, hotspot lịch trình)
- `samples/{id}/checkpoints/step_*.png`, `images/{id}_{source,target,adversarial}.png` (pixel-level audit)
- `code/attack.py`, `code/saga_regions.py`, `code/foa_loss.py`, `code/concept_attention.py`, `code/observer.py` (logic được lưu trong archive)

Không có caption mới hoặc đánh giá từ victim LVLM trên outputs của chính run này. Không suy diễn Attack Success Rate (ASR), transferability, hay targeted success từ objective hoặc attention maps. Caption `caption_record.captions.adversarial` trong sample metadata có nguồn từ run cũ và không phải kết quả đánh giá của run hiện tại (100/100 image hashes tương ứng khác ảnh adversarial cuối trong archive).

## Thiết lập

- 100/100 mẫu hoàn tất, mỗi mẫu 300 bước; seed bắt đầu 2023; Qwen3-VL-8B-Instruct, layer 29, concept theo caption source cố định.
- `ATTENTION_MODE=dynamic`, recompute mỗi 30 bước; 11 guide maps / ảnh (step 0 đến step 300), trong đó step 300 chỉ phục vụ logging.
- 10 phases, 3 top hotspots/phase trừ phase 10 chỉ có 1 box toàn ảnh do geometry; tổng 28 entries.
- Surrogate `B16`, `B32`, `Laion`; FOA global/local OT, dynamic ensemble weights; epsilon 16/255, alpha 1/255, image resolution 224×224.
- Attention map là probability grid 14×14, mỗi map có tổng 1. Hotspot được chọn bằng min-max-normalized map. Mọi ghi nhận hotspot mass bên dưới dùng probability map chưa min-max.
- Kaggle GPU: 2× Tesla T4, attack trên GPU0 và attention trên GPU1. Toàn session 15,371.78 giây (4.27 giờ), mean 151.79 giây/mẫu; loading 191.98 giây.

## Phát hiện định lượng

| Chỉ số | Step 0 | Step 30 | Step 150 | Step 300 |
|---|---:|---:|---:|---:|
| Attention mass trong **hotspot được chọn tại step 0** | 0.2862 | 0.1668 | 0.1133 | 0.1127 |
| Pearson correlation với map gốc (mean) | 1.000 | 0.451 | 0.164 | 0.126 |
| L1 attention distance với map gốc (mean) | 0.000 | 0.620 | 1.034 | 1.101 |
| Top 20 patches Jaccard với step 0 (mean) | 1.000 | 0.466 | 0.151 | 0.109 |
| Mean *raw* image-attention mass | 0.1400 | 0.1349 | 0.1216 | 0.0983 |
| Mean absolute pixel perturbation /255 | 0.000 | 0.4435 | 3.8561 | 6.8515 |
| Tỷ lệ pixel có ít nhất một channel khác source | 0.00% | 19.44% | 90.82% | 99.36% |
| Fraction RGB channels khác đúng 16/255 ở saved image | 0.00% | 0.0026% | 1.29% | 5.18% |

- Hotspot ban đầu phủ **9.18%** các patch nhưng chứa trung bình 28.62% attention khi t=0 (khoảng 3.12 lần uniform baseline). Đến step 300 chỉ còn 11.27% (~1.23 lần uniform baseline): giảm trung bình 17.35 điểm phần trăm, tương ứng 60.6% relative reduction; 98/100 mẫu giảm. Paired t-test (theo mẫu, n=100): p ≈ 6.37×10⁻²⁷. So sánh này mô tả vùng tĩnh; KHÔNG chứng minh attention mass đã di chuyển vào các vùng mang ngữ nghĩa đúng.
- Raw image-attention mass giảm ở 90/100 ảnh, mean 14.00% → 9.83%, tức decoder concept tokens dành tỷ lệ attention nhỏ hơn cho vision-token keys. Đây là metric *trước* normalization trên visual tokens, không phải tỷ lệ nhận thức thị giác của mô hình.
- Top-20 visual-patch mass (khoảng 10.2% grid): 51.27% ở clean image → 42.57% ở step 300; có khuynh hướng bớt tập trung trên top patches dù có spike bất thường ở một số ảnh.
- Từng giai đoạn 30 bước: attention mass đo trên union các crops đã chỉnh sửa giảm ở 696/1000 cặp giai đoạn/ảnh; 97/100 ảnh có mức thay đổi trung bình theo các giai đoạn là âm. Tuy nhiên, union tăng nhanh và ở các giai đoạn cuối gần toàn ảnh; metric này không phải kiểm định causal theo thiết kế ablation.

## Objective, budget và confounds

- Mean logged FOA objective ở các block 30 bước: 1.486, 1.780, 1.954, 2.060, 2.252, 2.449, 2.594, 2.679, 2.721, **2.768**. Cả 100 ảnh có block cuối > block đầu.
- **Không được diễn giải sự tăng của số này là improvement trên một objective đo trong điều kiện cố định**: random cropped source lẫn target được sample lại mỗi iteration, kích thước crop thay đổi theo stage; mean crop area so với toàn ảnh tăng từ 5.42% (1–30) đến 68.25% (271–300). Ngoài ra, dynamic weights cũng thay đổi qua iterations.
- Pearson giữa final L1 attention drift và difference logged objective (last block − first block) là **r=0.243, p=0.015**, n=100; effect yếu, mang tính observational và bị confound. Không đủ để khẳng định attention shift khiến target alignment tăng.
- Internal Linf max của delta đạt 16 (theo đơn vị 0–255) lần đầu trung bình tại step 26.54 (min 16, max 50), và tất cả ảnh có ít nhất một channel chạm budget tại step 50. Đây **không phải saturation toàn ảnh**: sau 300 bước chỉ 5.18% RGB channels trên PNG cuối có absolute difference đúng 16/255; mean pixel/channel absolute difference là 6.85/255.
- Đến 300 bước, 99.36% pixel đã thay đổi ít nhất một channel. Như vậy update tập trung từng vùng theo iteration không đồng nghĩa perturbation cuối chỉ tồn tại ở một vùng nhỏ.

## Những bất thường quan trọng

### (A) Attention rebound / oscillation candidate

Định nghĩa kiểm đếm: có checkpoint kể từ step 90 mà Pearson với map gốc ≥0.8, trong khi một checkpoint trước đó Pearson <0.2. Có 5/100 mẫu: `00017`, `00018`, `00023`, `00080`, `00084`.

- Sample `00023` (source caption: *A bear is laying in the grass next to a rock.*): initial-region attention mass 0.5323 (step 0), 0.6301 (step 180), 0.1073 (step 300); Pearson map với clean đạt 0.996 ở step 180 nhưng −0.054 ở step 300. Bản đồ không biến đổi một chiều.
- Sample `00080` (*A bird statue is perched on a rock.*): initial-region mass 0.3829 → 0.052 (step 150) → 0.4573 (step 240) → 0.5411 (step 300); final Pearson 0.966. Một hotspot ở phần bầu trời/vùng rìa ảnh thay vì hiển nhiên nằm trên tượng chim cũng nhắc rằng attention không phải lúc nào đồng nghĩa semantic importance; cần kiểm tra grounding fidelity.
- Figure `attention_case_montage.png` minh họa thêm sample `00000` (panda), có attention peak từ 0.296 ở step 0 đổi vị trí ngay step 30, tiếp tục đổi tới step 300.

### (B) Dynamic guidance mất vai trò khu biệt dần về cuối

Mean IoU giữa box trong **đúng scheduled position sắp sử dụng** trên dynamic map với position đó trong fixed map step 0: step 30 = 0.465, step 60 = 0.503, step 120 = 0.594, step 180 = 0.743, step 240 = 0.936, step 270 = 1.000. Tại step 270, 100/100 box là toàn ảnh bất kể attention map. Trong nửa sau, diện tích cố định tăng khiến lựa chọn không còn phân biệt được hotspot; dynamic Qwen overhead lúc cuối không đổi region.

### (C) Thiết lập IoU=0.3 bị fallback phá vỡ

Tính IoU mọi cặp top-3 hotspot thuộc phase tương ứng của mỗi mẫu (100 × 9 × 3 = 2.700 pairwise comparisons): **1.199/2.700 = 44.4%** IoU >0.3. Mean pairwise IoU: phase1=0.149, phase4=0.240, phase5=0.361, phase6=0.572, phase7=0.765, phase8=0.825, phase9=0.864. Phase7–9: 100% pairs >0.3.

Code `get_top_k_boxes_fixed_area()` có fallback chấp nhận overlap sau khi thử chọn theo IoU; đây là hành vi code chủ động, không phải log bị ghi sai. Tuy nhiên overlap tăng rất mạnh làm giảm ý nghĩa "3 hotspots độc lập" trong late-stage.

### (D) Fixed source concept và sự phụ thuộc vào nội dung ảnh

`GUIDE_CAPTION_ROLE=source`; query text là caption nguồn cố định và được đưa vào teacher-forced attention, không phải câu caption mới sinh mỗi checkpoint. Trong 100 ảnh, guide/source maps giống hệt nhau vì dùng cùng concept text. Source-target attention maps tại step0 có mean Pearson 0.718 dù target caption khác; 44/100 mẫu có r>0.8. Chẳng hạn sample `00000` (panda vs *a dog with a toothbrush*) có r=0.984 tại step0. Điều này làm phát sinh nghi vấn về concept-specific selectivity, nhưng cần random text, shuffled captions, và patch-occlusion ground truth mới kết luận được.

### (E) Historical adversarial caption không phải kết quả của run hiện tại

Trong `sample_config.json`, `caption_record.captions.adversarial` và SHA256 tương ứng đến từ nguồn `caption_origin.caption_reference = outputs/foa_attack/text_generation_v1_1_20261007T032741067291Z`. SHA256 ảnh adversarial caption record **khác** SHA256 ảnh cuối của run này ở **100/100 samples**. Không dùng các caption đó để tuyên bố thành công targeted attack.

### (F) Quy trình objective thay đổi nội bộ

Trong `code/attack.py`, mỗi iteration gọi `loss_fn.set_ground_truth(target_crop(image_tgt))`, và trước khi gradient trên crop sẽ tính thêm một full-image pass, cập nhật `loss_fn.previous_loss_list` dù nhánh này đặt trong `no_grad()`. Do đó objective trên crop có dynamic ensemble weights với trạng thái vừa được đổi bởi full-image forward. Cần benchmark với một chuẩn fixed-evaluation độc lập; chưa đủ dữ liệu để kết luận đó là bug hoặc làm giảm ASR. Code cũng tính embedding trên `image_org + delta` trước khi clamp ảnh về [0,255] khi export, tạo khả năng sai lệch với ảnh thực đưa vào victim, cần instrument đo.

## Những giả thuyết nghiên cứu (chưa được chứng minh)

1. **Loss-sensitive attention guidance**: hotspot có attention cao ở iteration t không nhất thiết có largest positive FOA improvement trong step tiếp theo. Hãy đánh giá counterfactual update hiệu quả ở cùng epsilon/compute (loss gain per unit changed-pixel-budget) để học hotspot utility.
2. **Retention/anti-oscillation**: nếu region attention quay lại, phạt chọn lặp lại hoặc dùng EMA, hysteresis, hoặc cooldown khi không có improvement; so sánh trên nhóm rebound và toàn tập.
3. **Late-stage saturation / duplicate region updates**: giữ diện tích region ≤50%, dùng top-K disjoint/non-overlap với mask exclusion thật sự, hoặc chỉ cho update hotspot có marginal utility > threshold.
4. **Concept guidance validation**: so sánh source, target, hybrid, random/shuffled caption, occlusion/GradCAM, và random-region baseline. Sử dụng target concept không có nghĩa model nhìn đối tượng target thật trong ảnh.
5. **Dynamic vs fixed fairness**: phải có fixed-clip objective evaluator, same image pairs, same seeds, same 300 updates, same surrogate models, same target texts and epsilon; kiểm soát Qwen recompute frequency/compute.

## Ablation ưu tiên và protocol

A0. Baseline FOA (random global crop). A1. SAGA fixed concept guide. A2. Current dynamic version (this archive). A3. Dynamic refresh only for first 150 updates, fixed later. A4. Dynamic + 0.7/0.3 EMA on normalized probability maps + IoU cooldown. A5. Dynamic + hotspot size cap at 50% + strict IoU<=0.3 (allow fewer than k, no fallback). A6. Dynamic + source/target guide contrast. A7. Dynamic + low-cost sensitivity probe selection, with matched gradient compute.

Metrics: 100-pair development set before scaling; same victim generation prompt, paired victim outputs for attack success; gpt-oss/LLM-as-judge ASR and AvgSim with recorded exact judge/prompt/threshold; CLIP fixed-crop target similarity under constant validation crops; source similarity; sample-level confidence intervals and paired bootstrap; top-K attentions drift and held-out hotspot utility; clip Linf/mean abs/LPIPS/SSIM; time and Qwen overhead. Run several seeds and do not tune on final held-out test set.

Chỉ số *attack utility* có thể thiết kế: chọn crop r với reward `ΔL_eval(r) / (Δ pixel-budget + λ·runtime)` trong vài probe steps; với Qwen maps có thể dùng prior score rồi dùng utility làm rerank. Cần tránh làm tăng gradient queries không được tính vào compute budget.

## Kết luận

Experiment cung cấp bằng chứng rất rõ rằng concept-conditioned attention thay đổi mạnh trong quá trình FOA region-localized attack và hotspot ban đầu thường mất attention mass. Nhưng **không chứng minh** rằng dynamic attention có ASR tốt hơn fixed, rằng attention shift có causal contribution cho attack, hoặc rằng map đang phản ánh đúng những vùng nhạy cảm có khả năng transfer tới các black-box LVLM.

Vấn đề có tính ưu tiên cao nhất hiện tại: **hotspot schedule ở late-stage dần thành global/overlap, objective đo trên crop biến thiên, thiếu victim-side evaluation, và historical captions không hợp lệ để tính ASR**. Sau khi chuẩn hóa đánh giá, thử dynamic guidance có retention và strict sparse hotspots trước khi tăng quy mô dataset.

## File tái lập

- `samples.csv`: 100 dòng thống kê mỗi ảnh
- `checkpoints.csv`: 1.100 dòng thống kê mỗi image/checkpoint
- `stage_metrics.csv`: 1.000 dòng thống kê 30-step block/image
- `schedule_comparison.csv`: 900 dòng so sánh dynamic với fixed schedule
- `hotspot_iou_violations.csv`: 1.000 dòng IoU trong mỗi phase/image
- `concept_comparison.csv`: 300 dòng so sánh source và target attention theo các checkpoint có dữ liệu
- `traces.csv`: gộp 30.000 log iterations, đủ tham chiếu từng objective/crop/schedule
- `analyze_adv_results.py`, `check_overlap.py`, `make_figs.py`: tính toán và visualization (chạy trực tiếp trên archive có cùng tên)
