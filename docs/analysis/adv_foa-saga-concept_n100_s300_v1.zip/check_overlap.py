import zipfile,json,numpy as np,pandas as pd
z=zipfile.ZipFile('/mnt/data/adv_foa-saga-concept_n100_s300_v1.zip')
def mask(box):
 t,l,h,w=box;t=int(t*14);l=int(l*14);h=int(h*14);w=int(w*14)
 m=np.zeros((14,14),bool);m[t:t+h,l:l+w]=1;return m
def iou(a,b):
 a,b=mask(a),mask(b)
 return (a&b).sum()/(a|b).sum()
vals=[]
for j in range(100):
 sid=f'{j:05d}'
 for phase in range(1,11):
  step=(phase-1)*30;s=json.loads(z.read(f'samples/{sid}/schedules/step_{step:05d}.json'))['schedule'];sel=[x for x in s if x['phase_group']==phase]
  scores=[iou(a['box'],b['box']) for k,a in enumerate(sel) for b in sel[k+1:]]
  vals.append(dict(sample_id=sid,phase=phase,count=len(sel),mean_iou=float(np.mean(scores)) if scores else None,max_iou=max(scores) if scores else None,violating_pairs=sum(x>.3 for x in scores),total_pairs=len(scores),exceeds_any=sum(x>.3 for x in scores)>0))
d=pd.DataFrame(vals);d.to_csv('/mnt/data/attack_analysis/hotspot_iou_violations.csv',index=False)
print(d.groupby('phase')[['count','mean_iou','max_iou','violating_pairs','total_pairs','exceeds_any']].mean().round(3).to_string()); print('total violations',d.violating_pairs.sum(),'of',d.total_pairs.sum())
