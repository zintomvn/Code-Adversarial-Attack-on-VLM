import zipfile,io,json,csv,os,math
from PIL import Image
import numpy as np,pandas as pd
from scipy.stats import spearmanr,pearsonr
Z='/mnt/data/adv_foa-saga-concept_n100_s300_v1.zip';out='/mnt/data/attack_analysis';os.makedirs(out,exist_ok=True)
z=zipfile.ZipFile(Z)
steps=list(range(0,301,30))
def readjson(p):return json.loads(z.read(p))
def readpng(path):return np.array(Image.open(io.BytesIO(z.read(path))).convert('RGB'),dtype=np.int16)
def readnp(path,label='guide'):
 a=np.load(io.BytesIO(z.read(f'{path}/{label}.npz')))
 return np.asarray(a['probability'],dtype=np.float64)
def boxmask(box,H=14,W=14):
 t,l,h,w=box
 t,l=max(0,min(H-1,int(t*H))),max(0,min(W-1,int(l*W)))
 h,w=max(1,int(h*H)),max(1,int(w*W))
 mask=np.zeros((H,W),bool);mask[t:min(H,t+h),l:min(W,l+w)]=True
 return mask

def box_iou(b1,b2):
 m1=boxmask(b1);m2=boxmask(b2)
 return (m1&m2).sum()/(m1|m2).sum()
def cor(a,b):
 a=a.ravel();b=b.ravel();return np.corrcoef(a,b)[0,1]
def top_jaccard(a,b,n=20):
 ia=np.argsort(a.ravel())[-n:];ib=np.argsort(b.ravel())[-n:];return len(set(ia)&set(ib))/len(set(ia)|set(ib))
alltr=[];check=[];segments=[];samples=[];outlier=[];compare=[];cropmetrics=[]
for j in range(100):
 sid=f'{j:05d}';base=f'samples/{sid}'
 cfg=readjson(f'{base}/sample_config.json')
 tr=pd.read_csv(io.BytesIO(z.read(base+'/trace.csv')));tr['sample_id']=sid
 alltr.append(tr)
 assert len(tr)==300
 ini=readpng(f'images/{sid}_source.png');final=readpng(f'images/{sid}_adversarial.png')
 maps=[readnp(f'{base}/attention/step_{step:05d}') for step in steps]
 rms=[readjson(f'{base}/attention/step_{step:05d}/guide.json')['mean_raw_vision_mass'] for step in steps]
 m0=maps[0];p0=m0.ravel();initbox=readjson(f'{base}/schedules/step_00000.json')['schedule'][0]['box'];mask0=boxmask(initbox)
 schedule0=readjson(f'{base}/schedules/step_00000.json')['schedule']
 ss=readjson(f'{base}/status.json')
 for i,step in enumerate(steps):
  p=maps[i];flat=p.ravel();q=flat/flat.sum();entropy=-np.sum(q*np.log(q+1e-30))/np.log(len(q));topmass=np.sort(q)[-20:].sum()
  peak=np.unravel_index(np.argmax(p),p.shape)
  ini_peak=np.unravel_index(np.argmax(m0),m0.shape)
  snap=readpng(f'{base}/checkpoints/step_{step:05d}.png')
  dv=np.abs(snap-ini)
  check.append(dict(sample_id=sid,step=step,attention_L1_init=float(np.abs(p-m0).sum()),attention_L1_prev=float(np.abs(p-maps[i-1]).sum()) if i else 0,attention_corr_init=cor(p,m0),attention_corr_prev=cor(p,maps[i-1]) if i else 1.,top10_jaccard_init=top_jaccard(p,m0),top10_jaccard_prev=top_jaccard(p,maps[i-1]) if i else 1.,initial_hotspot_mass=float(p[mask0].sum()),top10_attention_mass=topmass,entropy_norm=entropy,max_patch_prob=float(flat.max()),peak_dist_init=float(np.hypot(peak[0]-ini_peak[0],peak[1]-ini_peak[1])),mean_raw_vision_mass=rms[i],mean_abs_perturb_255=float(dv.mean()),pct_pixels_changed=float(np.any(dv>0,axis=2).mean()),pct_channels_at_bound=float((dv>=16).mean()),pct_pixels_at_bound=float(np.any(dv>=16,axis=2).mean()),pct_channels_near_bound=float((dv>=15).mean()),linf_saved_255=int(dv.max()),guide=cfg['guide']))
  if i and i<10:
   idx=min(step//(300//len(schedule0)),len(schedule0)-1)
   current=readjson(f'{base}/schedules/step_{step:05d}.json')['schedule'][idx]['box']
   old=schedule0[idx]['box']
   prev=readjson(f'{base}/schedules/step_{step-30:05d}.json')['schedule'][idx]['box']
   compare.append(dict(sample_id=sid,step=step,index=idx,phase=readjson(f'{base}/schedules/step_{step:05d}.json')['schedule'][idx]['phase_group'],iou_vs_fixed=box_iou(current,old),iou_vs_previous_schedule=box_iou(current,prev),identical_fixed=float(boxmask(current).tolist()==boxmask(old).tolist()),delta_centre_cells=float(np.hypot((current[0]+current[2]/2-old[0]-old[2]/2)*14,(current[1]+current[3]/2-old[1]-old[3]/2)*14))))
 for i in range(1,len(steps)):
  seg=tr[(tr.step>steps[i-1])&(tr.step<=steps[i])]
  attacked=np.zeros((14,14),bool)
  for crop in seg.crop:
   t,l,h,w=json.loads(crop);a,b=int(t/16),int(l/16);c,d=int(np.ceil((t+h)/16)),int(np.ceil((l+w)/16))
   attacked[max(0,a):min(14,c),max(0,b):min(14,d)]=True
  prev,cur=maps[i-1],maps[i]; massprev=float(prev[attacked].sum());masscur=float(cur[attacked].sum());
  segments.append(dict(sample_id=sid,step_start=steps[i-1],step_end=steps[i],attacked_grid_coverage=float(attacked.mean()),attacked_mass_pre=massprev,attacked_mass_post=masscur,delta_attacked_mass=masscur-massprev,attacked_mass_declined=int(masscur<massprev),mean_objective=float(seg.objective.mean()),objective_first=float(seg.objective.iloc[0]),objective_last=float(seg.objective.iloc[-1]),objective_median=float(seg.objective.median()),crop_mean_area=float(np.mean([np.prod(json.loads(x)[2:]) for x in seg.crop])/(224*224)),range_linf_start=float(seg.linf_internal_255.iloc[0]),range_linf_end=float(seg.linf_internal_255.iloc[-1])))
 diff=np.abs(final-ini);S=tr.objective.to_numpy()
 samples.append(dict(sample_id=sid,guide=cfg['guide'],target=cfg['concepts']['target'],mean_abs_final=float(diff.mean()),pct_changed_final=float(np.any(diff>0,axis=2).mean()),pct_bound_final=float((diff>=16).mean()),linf_final=int(diff.max()),att_L1_final=float(np.abs(maps[-1]-m0).sum()),att_corr_final=cor(maps[-1],m0),init_hotspot_mass_start=float(m0[mask0].sum()),init_hotspot_mass_end=float(maps[-1][mask0].sum()),init_hotspot_mass_change=float((maps[-1]-m0)[mask0].sum()),att_top_jaccard_final=top_jaccard(maps[-1],m0),objective_mean_first30=float(S[:30].mean()),objective_mean_last30=float(S[-30:].mean()),objective_change_30blocks=float(S[-30:].mean()-S[:30].mean()),objective_mean_first100=float(S[:100].mean()),objective_mean_last100=float(S[-100:].mean()),time_seconds=readjson(f'{base}/timing.json')['total_seconds']))
trdf=pd.concat(alltr,ignore_index=True);df=pd.DataFrame(check);sdf=pd.DataFrame(samples);gdf=pd.DataFrame(segments);cdf=pd.DataFrame(compare)
for name,frame in [('traces',trdf),('checkpoints',df),('samples',sdf),('stage_metrics',gdf),('schedule_comparison',cdf)]:frame.to_csv(out+'/'+name+'.csv',index=False)

def stats(col,frame=df):
 s=frame[col].dropna();return dict(n=len(s),mean=round(s.mean(),5),median=round(s.median(),5),std=round(s.std(),5),p10=round(s.quantile(.10),5),p90=round(s.quantile(.90),5),min=round(s.min(),5),max=round(s.max(),5))
print('NUM samples/traces/maps',len(sdf),len(trdf),len(df))
print('FINAL')
for k in ['att_L1_final','att_corr_final','init_hotspot_mass_start','init_hotspot_mass_end','init_hotspot_mass_change','att_top_jaccard_final','mean_abs_final','pct_changed_final','pct_bound_final','objective_change_30blocks','time_seconds']: print(k,stats(k,sdf))
print('ATTENTION at checkpoints')
print(df.groupby('step')[['attention_L1_init','attention_L1_prev','attention_corr_init','attention_corr_prev','top10_jaccard_init','initial_hotspot_mass','top10_attention_mass','entropy_norm','mean_raw_vision_mass','mean_abs_perturb_255','pct_channels_at_bound','pct_pixels_changed']].agg(['mean','median']).round(4).to_string())
print('STAGE')
print(gdf.groupby('step_end')[['attacked_grid_coverage','attacked_mass_pre','attacked_mass_post','delta_attacked_mass','attacked_mass_declined','mean_objective','crop_mean_area']].mean().round(4).to_string())
print('COMPARE')
print(cdf.groupby('step')[['iou_vs_fixed','iou_vs_previous_schedule','delta_centre_cells']].agg(['mean','median']).round(4).to_string());print('all',[(c,stats(c,cdf)) for c in ['iou_vs_fixed','iou_vs_previous_schedule']])
print('OBJ TRACE OVERALL')
trdf['block']=((trdf.step-1)//30)*30+30
print(trdf.groupby('block').objective.agg(['mean','median','std']).round(5).to_string());print('bad steps',trdf.isna().sum().to_dict());print('accuracy',(trdf.linf_internal_255<=16.00001).mean());print('early saturation',trdf.groupby('step').linf_internal_255.apply(lambda s:float((s>=16).mean())).loc[[1,10,20,30,50,100,200,300]].to_dict())
print('interesting')
print('worst 5 initmass',sdf.sort_values('init_hotspot_mass_change').head(5)[['sample_id','guide','init_hotspot_mass_start','init_hotspot_mass_end','att_corr_final','att_L1_final']].to_string(index=False))
print('best 5 increases',sdf.sort_values('init_hotspot_mass_change',ascending=False).head(5)[['sample_id','guide','init_hotspot_mass_start','init_hotspot_mass_end','att_corr_final','att_L1_final']].to_string(index=False))
print('low init- final corr',sdf.sort_values('att_corr_final').head(10)[['sample_id','guide','att_corr_final','att_L1_final','objective_change_30blocks']].to_string(index=False))
print('corr foa vs attention shift',pearsonr(sdf['objective_change_30blocks'],sdf['att_L1_final']),spearmanr(sdf['objective_change_30blocks'],sdf['att_L1_final']))
print('corr foa vs reduced hotspot',pearsonr(sdf['objective_change_30blocks'],-sdf['init_hotspot_mass_change']))
print('cases hotspot mass dropped',int((sdf.init_hotspot_mass_change<0).sum()))
print('stage mass decreased',int(gdf.attacked_mass_declined.sum()),len(gdf))
print('stage mass baseline random mean deltas',gdf.delta_attacked_mass.mean())
print('attacked mass changes quantiles',gdf.delta_attacked_mass.quantile([0.05,.25,.5,.75,.95]).to_dict())
print('time overall',readjson('summary.json')['session_seconds'])
